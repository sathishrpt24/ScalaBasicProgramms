package Match

object MatchCase {
  
  def main(args:Array[String]){
    
    var mode = "1";
    
    mode match{
      
      case "1"=> println("This is case 1");
      case "2"=> println("This is case 2");
      case "3"=> println("This is case 3");
      case "4"=> println("This is case 4");
      case "5"=> println("This is case 5");
      
      case _=> println("Enter valid case number");
    }
    
  }
  
}