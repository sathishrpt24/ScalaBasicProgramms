//package Functions
//
//object AddingNum {
//  
//  def main(args:Array[String]){
//        
//  }
//  
//  def input(a:Int):Int = {
//    
//    a;
//    
//  }
//  
//  def input1(b:Int):Int = {
//    
//    b;
//    
//  }
//  def addNum(f1: ,f2: ){
//    
//    println(a+b);
//  }
//}