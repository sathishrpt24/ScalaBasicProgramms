package Functions

object CheckStock {
  
  def checkItem(itemName:String,shopBranch:String):Boolean={
    
    var itemList = Array("Pen","Pencil","Book");
    
    var findAvilablity = (itemName:String,shopBranch:String)=>{
    
    var itemavailable: Boolean = false;
    
    for(i<-itemList){
      
      if(i.equals(itemName)){
        
        if(shopBranch.equals("Vegas")){
         var itemAvailable = true;
        }
      }
      
    }
    itemavailable
    
  }
    
    val isAvailable = findAvilablity(itemName,itemName);
    isAvailable
  }

  def main(args:Array[String]){
    
    val itemName = "Pen";
    val shopBranch = "Vegas"
    
    val result = checkItem(itemName,shopBranch);
    
    println("The given item is available: "+result);
  }
}
