package Functions

object FunctionWithDefaultValues {
  
  def main(args:Array[String]){
    
    println(addName("Sathish"));
  }
  
  def addName(x:String,text:String="Mr")={
    text.concat(x);    
  }
}