package Functions

object Function1 {
  
  def print1()={
    var name = "Sathish";
    name.toLowerCase;
  }
  def show(a: =>String){
    println(a);
  }
   def main(args:Array[String]){
    
     println("Main method started");
     show(print1());
  }
  
}
