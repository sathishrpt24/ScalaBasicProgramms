

object ArrayFuntions {

  def main(args: Array[String]) {

    val myMenu = Array("Java", "Selenium", "Jenkins", "GIT",
      "Scala", "Spark", "SQL", "Python", "Numpy", "Pandas");

    for (x <- myMenu) {

      println("Values inside the menu:" + x);
    }
    
    val mArray = Array.ofDim[Int](2,2);
    
    mArray.update(0, Array(0,0));
  /*  mArray.update(10, Array(0,1));
    mArray.update(10, Array(0,2));
    mArray.update(10, Array(1,0));
    mArray.update(10, Array(1,1));
    mArray.update(10, Array(1,2));
    mArray.update(10, Array(2,0));
    mArray.update(10, Array(2,1));
    mArray.update(10, Array(2,2));*/
    
//    for(i<- 0 to 2){
//      for(j<-0 to 2){
//        println(""+mArray(i)(j));
//      }
//    }
    
    println(""+mArray(0)(0));
    
    
  }

}