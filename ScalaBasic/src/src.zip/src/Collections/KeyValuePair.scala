package Collections

import scala.collection.SortedMap

object KeyValuePair {
  
  def main(args:Array[String]){
    
    var CountryCapital = SortedMap("India"->"Delhi","Srilanka"->"Columbo","Australia"->"Canberra")
    
    println(CountryCapital.keysIterator.hasNext);
    
    println(CountryCapital.keySet)
    
    println(CountryCapital.values)
    
    CountryCapital.keys.foreach { i =>
      
      println("Keys"+i);
      
      println("Values:"+CountryCapital(i));
    }
    
  }
}