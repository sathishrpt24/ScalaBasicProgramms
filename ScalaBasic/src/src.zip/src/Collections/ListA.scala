package Collections

object ListA {
  
  def main(args:Array[String]){
    
    var test1 = List.range(5,55,5)
    
    var list1 = List.tabulate(5)(n=>n*2)
    
   // var List2 = List.tabulate[Int](2, 3, 4)(f(1,2,3)=>n*2);
    
    println(test1);
    println(list1);
    
   // var test3 = test1.foreach(n=>n*2);
  //  println(test3);
  }
  
}