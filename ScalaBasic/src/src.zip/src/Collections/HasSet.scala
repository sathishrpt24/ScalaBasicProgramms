package Collections

import scala.collection.mutable.HashSet

//import scala.collection.mutable.HashSet

object HasSet {
  
  def main(args:Array[String]){
    
    var continents = HashSet("South America","North America","Asia","Australia","Africa","Europe","Antartica");
    
    continents.+=("None");
    
    println("Added new element: "+continents);
   
    continents.-=("Asia");
    
    println("Remove element: "+continents);
    
    continents.foreach(println);
    println("Itertor:"+continents.iterator);
    
    var newcon = continents.map(n=> n+"1");
    
    println(newcon);
    
    var newcon2 = continents.drop(1)
    
    println(newcon2);
    
    var newcon3 = continents.filter(_.contains("e"));
    
    println(newcon3)
    
  }
}