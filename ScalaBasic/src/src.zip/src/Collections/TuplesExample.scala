package Collections

object TuplesExample {
  
  def main(args:Array[String]){
 
    var TupleEx = Tuple5("Sathish","Ponnu",100,200,300);
    
    println(TupleEx._1);
    println(TupleEx._2);
    println(TupleEx._3);
    println(TupleEx._4);
    println(TupleEx._5);
    
    TupleEx.productIterator.foreach(println)
    
    println(TupleEx.toString())
    //println("Through iterator: "+TupleEx.productIterator)
    
    println(TupleEx.notify())
    
  }
}