

object StringInterapolation {
  
  def main(args:Array[String]){
    
      var name ="Sathish";
      var Experience= 9;
      var company = "Accenture";
      
      println(s"Employeename:$name is having $Experience years of expereince in $company company ");
  }
}