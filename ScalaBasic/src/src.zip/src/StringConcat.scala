

object StringConcat {
  
  def main(args:Array[String]){
      
      var Street1 = "10th Street-"
      var City = "Philly";
      var state = "newJersy"
      
      var Address = Street1.concat(City).concat(state);
       
      var MyDetails = "This is my address - ".concat(Address);
      
      println(MyDetails);
      println(MyDetails.charAt(3));
      println(MyDetails.indexOf("is"));
      println("Length: "+MyDetails.length());
      
      println(MyDetails.slice(30,46));
  }
}