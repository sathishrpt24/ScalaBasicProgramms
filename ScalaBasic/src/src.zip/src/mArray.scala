

object mArray {
  
  def main(args:Array[String]){
    
    var Array1:Array[Int] = new Array[Int](4);
    
    var Array2:Array[String] = new Array[String](2);
    
   // var Array3 = new Array[String](2);
    
    val EvenNum = Array.tabulate(5)(n=>n*2);
    
    Array1.update(0, 5);
    Array1.update(0, 10);
    Array1.update(0, 15);
    Array1.update(0, 20);  
   // Array1.update(0, 25);
    
    Array2.update(0, "This");
    Array2.update(0, "is");
    Array2.update(0, "Scala ");
    Array2.update(0, "Basics");
    
    for(i<- 0 to 3){
      
     println(Array1(i));
    }
    
  }
  
}