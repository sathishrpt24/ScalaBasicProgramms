package readingInputs

object ReadString {
  
  def main(args:Array[String]){
    
    var service = readLine("Enter string");
    var service1 = readInt();
    println(service);
    println(service1);
  }
}