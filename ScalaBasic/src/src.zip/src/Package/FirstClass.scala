package Package

class FirstClass {
  
    def test1(){
      println("This is my firstclass");
    }
  
  
    def test2(){
      println("This is my firstclass's function 2");
    }

}