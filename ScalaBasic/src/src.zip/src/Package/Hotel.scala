package Package

class HotelWelcome {
  
  def chooseServiceType(ourService:String) =ourService match{
    case "Banquets"=>
      println("We offer indoor catering at affordable prices")
      println("Please send your details to us. We will contact you shortly.")
    case "Outdoor catering"=>
      println("We offer outdoor catering which is best in class ")
      println("Please send your details to us. We will promise you to " +
        "offer at affordable price.")
    case "Fine dining"=>
      println("Our wide range of cuisines will tickle your taste buds")
      println("We welcome you to explore")
    case "Order online"=>
      println("Free delivery within three kilometers")
      println("We accept all cards")
      
    //case _ => throw new IncoorectException("Incoorect");
    
  }
  
}
