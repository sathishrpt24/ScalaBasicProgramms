

object F_Interapolation {
  
  def main(args:Array[String]){
     
    var radius:Int =5;
    
    var area = radius*radius*3.14;
    
    println(f"Radius= $radius%.3f the area is $area%.2f");
    
  }
}